<?php

// $DATABASE_HOST = 'localhost';
// $DATABASE_USER = 'root';
// $DATABASE_PASS = '';

$DATABASE_HOST = 'sql202.epizy.com';
$DATABASE_USER = 'epiz_34089309';
$DATABASE_PASS = 'qyTznwgDab6AInY';

$DATABASE_NAME = 'epiz_34089309_techverse';
// $DATABASE_NAME = 'epiz_33865116_foodapp';


$con = new mysqli($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS);    //Database of Menu Items
?>